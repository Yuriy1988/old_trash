var  m = new Mediator();

window.addEventListener('load', function () {
    var c = new BlockController();		       		   
}, false);


	



